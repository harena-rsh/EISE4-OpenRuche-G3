Changer les pins des capteurs selon le schematic.
Faire attention au moment de connecter les Grove des DHT22.